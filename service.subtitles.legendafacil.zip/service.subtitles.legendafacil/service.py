# -*- coding: UTF-8 -*-
# Copyright, 2020, Joel Silva.
# This program is distributed under the terms of the GNU General Public License, version 3.
# http://www.gnu.org/licenses/gpl.txt
# Rev. 1.0.0

import os
import sys
import xbmc
import re
import urllib
import urllib2
import xbmcvfs
import xbmcaddon
import xbmcgui,xbmcplugin


base = 'https://raw.githubusercontent.com/zoreu/legenda-facil-para-kodi/master/legendas/lista.txt'

def makeRequest(url):
    try:
        try:
            import cookielib
        except ImportError:
            import http.cookiejar as cookielib
        try:
            import urllib2
        except ImportError:
            import urllib.request as urllib2
        cj = cookielib.CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
        opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9')]
        data = opener.open(url).read()
        response = data.decode('utf-8')
        return response
    except:
        #pass
        response = ''
        return response


def listar_legendas(pesquisar=False):    
    if pesquisar and 'searchstring' in params:
        try:
            currentFileName = os.path.basename(xbmc.Player().getPlayingFile()).replace('.mkv','').replace('.mp4', '').replace('.rmvb', '').replace('.wmv', '').replace('.avi', '').replace('.flv', '').replace('.mov', '').replace('.mpeg','')
        except:
            currentFileName = ''
        try:
            pesquisa = urllib.unquote(params['searchstring'])
            if currentFileName > '':
                data = makeRequest(base).replace('\n','').replace('\r','')
                regex = re.compile('subtitle="(.+?)".+?anguage="(.+?)".+?lag="(.+?)".+?ating="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
                for sub,language,flag,rating in regex:
                    filename = urllib.unquote(os.path.basename(sub)).replace('.srt', '').replace('.vtt', '')
                    if re.search(pesquisa,filename,re.IGNORECASE):
                        li = xbmcgui.ListItem(label=language,label2=urllib.unquote(os.path.basename(sub)),iconImage=str(rating),thumbnailImage=flag)
                        u = sys.argv[0]+'?action=download&sub='+sub
                        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=li,isFolder=False)
        except:
            pass
    
    else:
        try:
            currentFileName = os.path.basename(xbmc.Player().getPlayingFile()).replace('.mkv','').replace('.mp4', '').replace('.rmvb', '').replace('.wmv', '').replace('.avi', '').replace('.flv', '').replace('.mov', '').replace('.mpeg','')
        except:
            currentFileName = ''
        try:
            if currentFileName > '':
                data = makeRequest(base).replace('\n','').replace('\r','')
                regex = re.compile('subtitle="(.+?)".+?anguage="(.+?)".+?lag="(.+?)".+?ating="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(data)
                for sub,language,flag,rating in regex:
                    filename = urllib.unquote(os.path.basename(sub)).replace('.srt', '').replace('.vtt', '')
                    filename2 = urllib.unquote(currentFileName)
                    if re.search(filename2,filename,re.IGNORECASE):
                        li = xbmcgui.ListItem(label=language,label2=urllib.unquote(os.path.basename(sub)),iconImage=str(rating),thumbnailImage=flag)
                        u = sys.argv[0]+'?action=download&sub='+sub
                        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=li,isFolder=False)
        except:
            pass


def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]

    return param
    
params=get_params()


if params['action'] == 'search':
    listar_legendas()            
            
elif params['action'] == 'manualsearch':
    listar_legendas(True)
        
elif params['action'] == 'download':
    if 'sub' in params:
        #xbmcgui.Dialog().ok('[COLOR white][B]AVISO[/B][/COLOR]', params['sub'])
        sub = params['sub']
        li = xbmcgui.ListItem(label2=os.path.basename(sub))
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=sub,listitem=li,isFolder=False)
xbmcplugin.endOfDirectory(int(sys.argv[1]))